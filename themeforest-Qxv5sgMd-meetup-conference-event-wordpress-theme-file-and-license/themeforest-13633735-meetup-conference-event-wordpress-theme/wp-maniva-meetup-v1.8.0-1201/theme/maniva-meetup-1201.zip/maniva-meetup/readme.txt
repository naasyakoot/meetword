=== Maniva Meetup ===

Maniva WordPress theme, Copyright (C) 2015 Templaza
Maniva WordPress theme is licensed under the GPL.

== Description ==

Welcome to Maniva – One Page WordPress Theme.

== Installation ==

You can install the theme through the WordPress installer under Themes - Install themes by searching for it.
Alternatively, you can download the file, unzip it and move the unzipped contents to the wp-content/themes folder of your WordPress installation. You will then be able to activate the theme.

== Documentation ==

The complete documentation of Maniva is located in "document" folder in this theme main folder. It is also accessable via Theme Options Panel acfter installing and activating this theme.