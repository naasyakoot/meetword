<div class="col-md-3 tz-sidebar">
   <?php
        if ( is_active_sidebar('maniva-meetup'."-sidebar-right")  )  :
            dynamic_sidebar('maniva-meetup'."-sidebar-right");
        endif;
    ?>
</div>