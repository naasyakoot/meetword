<?php

get_template_part('extension/system/megamenu/themeple_custom_menu');


if(is_admin()){

    get_template_part('extension/system/megamenu/ajax_functions');
}

?>