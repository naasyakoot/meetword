<div class="tzquick-wrap">
    <div class="product-quick-warp">
        <div class="container">
            <span class="tzdelete-quick">
                <i class="fa fa-times"></i>
            </span>
            <div class="product-quick-content"></div>
        </div>
    </div>
</div>