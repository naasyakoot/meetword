
<?php if ( is_active_sidebar( 'maniva-meetup'."-sidebar-shop-detail" ) )  : ?>

    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 tz-sidebar">

        <?php dynamic_sidebar( 'maniva-meetup'."-sidebar-shop-detail" ); ?>

    </div>

<?php endif; ?>