<?php

function theme_enqueue_styles() {

    $maniva_meetup_parent_style = 'style';

    wp_enqueue_style('bootstrap-child', get_template_directory_uri() . '/css/default/bootstrap.min.css', false );
    wp_enqueue_style( $maniva_meetup_parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $maniva_meetup_parent_style )
    );

}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );
