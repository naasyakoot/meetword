

Maniva Meetup is a simple and easy-to-use theme which is created for business sites and conference purposes. There are lots of featured sections for Speakers, Event Schedule, FAQ's, Registration Form and a location map. With many cutting-edge features, Maniva Meetup surely makes your works be effective and impressive among the other ones.